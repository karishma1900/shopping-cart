import React from 'react';
import { Link } from 'react-router-dom';

const ProductList = ({ products }) => {
  return (
    <div style={productListContainerStyle}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Product List</h2>
      <div style={productListStyle}>
        {products.map(product => (
          <div key={product.id} className="product-list-item" style={productCardStyle}>
            <Link to={`/product/${product.id}`} style={productLinkStyle}>
              <h3>{product.name}</h3>
              <p style={{ color: '#333' }}>Price: ${product.price}</p>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

const productListContainerStyle = {
  padding: '20px',
};

const productListStyle = {
  display: 'flex',
  justifyContent: 'space-evenly',
  flexWrap: 'wrap',
};

const productCardStyle = {
  width: '300px',
  border: '1px solid #ddd',
  padding: '15px',
  marginBottom: '20px',
  borderRadius: '8px',
};

const productLinkStyle = {
  textDecoration: 'none',
  color: 'blue',
  fontWeight: 'bold',
};

export default ProductList;
