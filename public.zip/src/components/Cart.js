import React from 'react';

const Cart = ({ cart }) => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Shopping Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {cart.map(item => (
            <div key={item.id} className="cart-item" style={cartItemStyle}>
              <p>{item.name} - ${item.price}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const cartItemStyle = {
  border: '1px solid #ddd',
  padding: '10px',
  marginBottom: '10px',
};

export default Cart;
