import React, { useEffect, useState } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { fetchProductDetails } from './Productdata'; // Adjust the path accordingly

const Product = ({ addToCart }) => {
  const { id } = useParams();
  const history = useHistory();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    const getProduct = async () => {
      try {
        const data = await fetchProductDetails(id);
        setProduct(data);
      } catch (error) {
        console.error('Error fetching product details:', error);
      }
    };

    getProduct();
  }, [id]);

  if (!product) {
    return <p style={loadingStyle}>Loading...</p>; // Add a loading state while fetching data
  }

  const handleAddToCart = () => {
    addToCart(product);
    // After adding to cart, navigate to the cart page
    history.push('/cart');
  };

  return (
    <div style={containerStyle}>
      <div style={contentStyle}>
        <h2>{product.name}</h2>
        <p style={{ marginBottom: '10px' }}>Price: ${product.price}</p>
        <button onClick={handleAddToCart} style={addToCartButtonStyle}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

const containerStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',

  maxwidth:'500px',
  height: '40vh', // Set the height of the container to the full viewport height
};

const contentStyle = {
  padding: '20px',
  textAlign: 'center',
};

const addToCartButtonStyle = {
  padding: '8px 16px',
  backgroundColor: 'green',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

const loadingStyle = {
  ...contentStyle,
  fontStyle: 'italic',
};

export default Product;
