// productData.js
const products = [
    { id: 1, name: 'Product 1', price: 20 },
    { id: 2, name: 'Product 2', price: 30 },
    // Add more products as needed
  ];
  
  const fetchProductDetails = (productId) => {
    // Replace this with your actual data retrieval logic
    const product = products.find((p) => p.id === parseInt(productId, 10));
    return Promise.resolve(product); // Simulating an asynchronous operation (e.g., API request)
  };
  
  export { products, fetchProductDetails };
  