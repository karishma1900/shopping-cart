// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ProductList from './components/ProductList';
import Product from './components/Product';
import Cart from './components/Cart';

const App = () => {
  const [products] = useState([
    { id: 1, name: 'Product 1', price: 20 },
    { id: 2, name: 'Product 2', price: 30 },
  ]);

  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    // Check if the product is already in the cart
    const isProductInCart = cart.some((item) => item.id === product.id);

    if (!isProductInCart) {
      // If the product is not in the cart, add it
      setCart([...cart, product]);
    }
  };

  return (
    <Router>
      <div>
        <Switch>
          <Route exact path="/">
            <ProductList products={products} />
          </Route>
          <Route path="/product/:id">
            <Product addToCart={addToCart} />
          </Route>
          <Route path="/cart">
            <Cart cart={cart} />
          </Route>
        </Switch>
      </div>
    </Router>
  );
};

export default App;
